import java.util.*;

class WordOccurrence implements Comparable<WordOccurrence> {
	String word;
	int count;

	public WordOccurrence(String word, int count) {
		this.word = word;
		this.count = count;
	}

	@Override
	public int compareTo(WordOccurrence other) {
		return Integer.compare(this.count, other.count);
	}
}

public class CountOccurrenceOfWords {

	public static void main(String[] args) {

		String text = "Good morning. Have a good class. " + "Have a good visit. Have fun!";

		Set<String> uniqueWords = new HashSet<>();

		Map<String, Integer> map = new HashMap<>();

		String[] words = text.split("[\\s+\\p{P}]");

		for (int i = 0; i < words.length; i++) {
			String key = words[i].toLowerCase();

			if (key.length() > 0) {
				uniqueWords.add(key);
				map.put(key, map.getOrDefault(key, 0) + 1);
			}
		}

		List<WordOccurrence> wordOccurrences = new ArrayList<>();

		for (String word : uniqueWords) {
			wordOccurrences.add(new WordOccurrence(word, map.get(word)));
		}

		Collections.sort(wordOccurrences);

		for (WordOccurrence occurrence : wordOccurrences) {
			System.out.println(occurrence.word + "\t" + occurrence.count);
		}
	}
}
