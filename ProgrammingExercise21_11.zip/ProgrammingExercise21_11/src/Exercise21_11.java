
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
public class Exercise21_11 extends Application {
    private Map<String, Integer>[] mapForBoy = new HashMap[2];
    private Map<String, Integer>[] mapForGirl = new HashMap[2];
    private Button btFindRanking = new Button("Find Ranking");
    private ComboBox<Integer> cboYear = new ComboBox<>();
    private ComboBox<String> cboGender = new ComboBox<>();
    private TextField tfName = new TextField();
    private Label lblResult = new Label();
    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Select a year:"), 0, 0);
        gridPane.add(new Label("Boy or girl?"), 0, 1);
        gridPane.add(new Label("Enter a name:"), 0, 2);
        gridPane.add(cboYear, 1, 0);
        gridPane.add(cboGender, 1, 1);
        gridPane.add(tfName, 1, 2);
        gridPane.add(btFindRanking, 1, 3);
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(5);
        gridPane.setVgap(5);
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(gridPane);
        borderPane.setBottom(lblResult);
        BorderPane.setAlignment(lblResult, Pos.CENTER);
        btFindRanking.setOnAction(e -> findRanking());
        Scene scene = new Scene(borderPane, 370, 160);
        primaryStage.setTitle("Exercise21_11");
        primaryStage.setScene(scene);
        primaryStage.show();
        for (int year = 2001; year <= 2010; year++) {
            cboYear.getItems().add(year);
        }
        cboYear.setValue(2001);
        cboGender.getItems().addAll("Male", "Female");
        cboGender.setValue("Male");
    }
    private void loadData(int year, Map<String, Integer>[] mapArray, int rankColumn, int boyNameColumn, int girlNameColumn) {
        String dataURL = "http://liveexample.pearsoncmg.com/data/babynamesranking" + year + ".txt";
        try {
            Scanner scanner = new Scanner(new URL(dataURL).openStream());
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] data = line.split("\t");
                if (rankColumn >= 0 && rankColumn < data.length && boyNameColumn >= 0 && boyNameColumn < data.length
                        && girlNameColumn >= 0 && girlNameColumn < data.length) {
                    String rankString = data[rankColumn].trim();
                    String boyName = data[boyNameColumn].trim();
                    String girlName = data[girlNameColumn].trim();
                    Map<String, Integer> boyMap = mapArray[0];
                    if (boyMap == null) {
                        boyMap = new HashMap<>();
                        mapArray[0] = boyMap;
                    }
                    Map<String, Integer> girlMap = mapArray[1];
                    if (girlMap == null) {
                        girlMap = new HashMap<>();
                        mapArray[1] = girlMap;
                    }
                    try {
                        int rank = Integer.parseInt(rankString);
                        boyMap.put(boyName, rank);
                        girlMap.put(girlName, rank);
                    } catch (NumberFormatException ex) {
                     
                    }
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    private void findRanking() {
        int selectedYear = cboYear.getValue();
        String selectedGender = cboGender.getValue();
        String selectedName = tfName.getText();
        loadData(selectedYear, mapForBoy, 0, 1, 3); // Load data for boy names
        loadData(selectedYear, mapForGirl, 0, 1, 3); // Load data for girl names
        Map<String, Integer>[] selectedMap = (selectedGender.equals("Male")) ? mapForBoy : mapForGirl;
        Map<String, Integer> yearMap = selectedMap[0]; 
        if (selectedGender.equals("Female")) {
            yearMap = selectedMap[1]; 
        }
        Integer ranking = yearMap.get(selectedName);
        if (ranking != null) {
            lblResult.setText(selectedName + "'s ranking in " + selectedYear + " is: " + ranking);
        } else {
            lblResult.setText(selectedName + " not found with selected items.");
        }
    }
    public static void main(String[] args) {
        launch(args);
    }
}

