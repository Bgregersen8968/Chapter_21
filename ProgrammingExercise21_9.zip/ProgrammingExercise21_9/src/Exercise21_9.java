import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Exercise21_9 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        Map<String, String> stateCapitalMap = new HashMap<>();
        stateCapitalMap.put("California", "Sacramento");
        stateCapitalMap.put("Connecticut", "Hartford");
        stateCapitalMap.put("Delaware", "Dover");
        stateCapitalMap.put("Florida", "Tallahassee");
        stateCapitalMap.put("Georgia", "Atlanta");
        stateCapitalMap.put("Hawaii", "Honolulu");
        stateCapitalMap.put("Idaho", "Boise");
        stateCapitalMap.put("Illinois", "Springfield");
        stateCapitalMap.put("Indiana", "Indianapolis");
        stateCapitalMap.put("Maine", "Augusta");
boolean continueLoop = true;        
while (continueLoop)
{
        System.out.print("Enter a state, or exit to quit: ");
        String userState = input.nextLine();

        if (userState.equalsIgnoreCase("exit")) { 
        	continueLoop = false;
        	System.out.print("Thank you for your participation.");
        }
        else if (stateCapitalMap.containsKey(userState)) {
            String capital = stateCapitalMap.get((userState));
            System.out.println("The capital of " + userState + " is: " + capital);
        } else {
            System.out.println("State not found in the map.");
        }
    }
}
}

